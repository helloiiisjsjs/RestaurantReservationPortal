<html>
<head><title>Restaurant Portal</title></head>
<body>
    <h1>Restaurant Portal</h1>
    <a href="index.php?action=addReservation">Add Reservation</a> |
    <a href="index.php?action=viewReservations">View Reservations</a>
</body>
</html>
