<html>
<head><title>Modify Reservation</title></head>
<body>
    <h1>Modify Reservation</h1>
    <form method="POST" action="index.php?action=modifyReservation">
        <input type="hidden" name="reservation_id" value="<?= htmlspecialchars($reservation['reservationId']) ?>">
        Customer Name: <?= htmlspecialchars($reservation['customerName']) ?><br>
        Contact Info: <?= htmlspecialchars($reservation['contactInfo']) ?><br>
        Reservation Time: <input type="datetime-local" name="reservation_time" value="<?= htmlspecialchars($reservation['reservationTime']) ?>" required><br>
        Number of Guests: <input type="number" name="number_of_guests" value="<?= htmlspecialchars($reservation['numberOfGuests']) ?>" required><br>
        Special Requests: <textarea name="special_requests"><?= htmlspecialchars($reservation['specialRequests']) ?></textarea><br>
        Favorite Table: <input type="text" name="favorite_table" value="<?= htmlspecialchars($reservation['favoriteTable']) ?>"><br>
        Dietary Restrictions: <textarea name="dietary_restrictions"><?= htmlspecialchars($reservation['dietaryRestrictions']) ?></textarea><br>
        <button type="submit">Update</button>
    </form>
    <a href="index.php?action=viewReservations">Back to Reservations</a>
</body>
</html>
