<html>
<head><title>View Reservations</title></head>
<body>
    <h1>All Reservations</h1>
    <table border="1">
        <tr>
            <th>Reservation ID</th>
            <th>Customer Name</th>
            <th>Contact Info</th>
            <th>Reservation Time</th>
            <th>Number of Guests</th>
            <th>Special Requests</th>
            <th>Favorite Table</th>
            <th>Dietary Restrictions</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($reservations as $reservation): ?>
        <tr>
            <td><?= htmlspecialchars($reservation['reservationId']) ?></td>
            <td><?= htmlspecialchars($reservation['customerName']) ?></td>
            <td><?= htmlspecialchars($reservation['contactInfo']) ?></td>
            <td><?= htmlspecialchars($reservation['reservationTime']) ?></td>
            <td><?= htmlspecialchars($reservation['numberOfGuests']) ?></td>
            <td><?= htmlspecialchars($reservation['specialRequests']) ?></td>
            <td><?= htmlspecialchars($reservation['favoriteTable']) ?></td>
            <td><?= htmlspecialchars($reservation['dietaryRestrictions']) ?></td>
            <td>
                <a href="index.php?action=modifyReservation&id=<?= $reservation['reservationId'] ?>">Modify</a> |
                <a href="index.php?action=deleteReservation&id=<?= $reservation['reservationId'] ?>" onclick="return confirm('Are you sure?')">Cancel</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
    <a href="index.php">Back to Home</a>
</body>
</html>
