<html>
<head><title>Update Dining Preferences</title></head>
<body>
    <h1>Update Dining Preferences</h1>
    <form method="POST" action="index.php?action=updatePreferences">
        Customer ID: <input type="text" name="customer_id" required><br>
        Favorite Table: <input type="text" name="favorite_table"><br>
        Dietary Restrictions: <textarea name="dietary_restrictions"></textarea><br>
        <button type="submit">Save Preferences</button>
    </form>
    <a href="index.php?action=viewReservations">Back to Reservations</a>
</body>
</html>
