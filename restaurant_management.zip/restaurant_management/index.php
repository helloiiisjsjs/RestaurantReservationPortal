<?php
require_once 'RestaurantServer.php';

$portal = new RestaurantPortal();
$portal->handleRequest();
?>
